<?php 

$sql = "update pet_test_xray_row set doctorid = $userid, eye = '$data->eye', temperate = '$data->temperate', other = '$data->other', treat = '$data->treat', status = '$data->status' where id = $data->id";
query($sql);

$sql = "select a.*, b.name as pet, c.name as customer, c.phone, d.first_name as doctor from pet_test_xray a inner join pet_test_pet b on a.petid = b.id inner join pet_test_customer c on b.customerid = c.id inner join pet_users d on a.doctorid = d.userid order by id desc limit 20";
$list = all($sql);

foreach ($list as $key => $value) {
  $sql = "select a.*, b.first_name as doctor from pet_test_xray_row a inner join pet_users b on a.doctorid = b.userid where a.xrayid = $value[id] order by time asc";
  $row = all($sql);
  foreach ($row as $index => $detail) {
    $row[$index]['time'] = date('d/m/Y', $detail['time']);
  }

  $sql = "select * from pet_test_xray_his where petid = $value[petid]";
  $his = obj($sql, 'id', 'his');

  $list[$key]['status'] = $row[count($row) - 1]['status'];
  $list[$key]['detail'] = $row;
  $list[$key]['time'] = date('d/m/Y', $value['time']);
  $list[$key]['his'] = implode(', ', $his);
}

$result['status'] = 1;
$result['list'] = $list;
