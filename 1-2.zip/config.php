<?php
$config = array(
	'servername' => 'localhost',
	'username' => 'root',
	'password' => '',
	'database' => 'petcoffee'
);

$shop_config = array(
	'servername' => 'localhost',
	'username' => 'root',
	'password' => '',
	'database' => 'watch'
);

$branch = 'test';